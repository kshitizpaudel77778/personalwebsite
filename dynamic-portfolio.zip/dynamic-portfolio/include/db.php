<?php
$db = mysqli_connect("localhost", "root", "", "iportfolio");

// if ($db) {
//     echo "Database is connected!";
// } else {
//     echo "Something is wrong with the database!";
// }
?>
