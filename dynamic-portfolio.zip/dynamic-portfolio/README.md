use localhost or live server 

database name is : iportfolio
login admin site url and after url type (/admin) like kshitiz.com.np/admin 
user admin : kshitiz.com.np
user pp : admin123